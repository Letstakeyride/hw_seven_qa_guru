pytest-3.6.4
=======================================

pytest 3.6.4 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at http://doc.pytest.org/en/stable/changelog.html.

Thanks to all who contributed to this release, among them:

* Anthony Sottile
* Bernhard M. Wiedemann
* Bruno Oliveira
* Drew
* E Hershey
* Hugo Martins
* Vlad Shcherbina


Happy testing,
The pytest Development Team
