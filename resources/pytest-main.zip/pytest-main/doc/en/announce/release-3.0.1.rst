pytest-3.0.1
============

pytest 3.0.1 has just been released to PyPI.

This release fixes some regressions reported in version 3.0.0, being a
drop-in replacement. To upgrade:

  pip install --upgrade pytest

The changelog is available at http://doc.pytest.org/en/stable/changelog.html.

Thanks to all who contributed to this release, among them:

      Adam Chainz
      Andrew Svetlov
      Bruno Oliveira
      Daniel Hahler
      Dmitry Dygalo
      Florian Bruhin
      Marcin Bachry
      Ronny Pfannschmidt
      matthiasha

Happy testing,
The py.test Development Team
